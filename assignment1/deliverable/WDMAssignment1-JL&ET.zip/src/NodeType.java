public enum NodeType {
		ELEMENT,
		ATTRIBUTE;
};