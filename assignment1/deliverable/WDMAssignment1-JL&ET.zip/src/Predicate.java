
public interface Predicate {
	public boolean isMatch(String s);
}
