public enum MatchState {
		OPEN,
		CLOSED;
}